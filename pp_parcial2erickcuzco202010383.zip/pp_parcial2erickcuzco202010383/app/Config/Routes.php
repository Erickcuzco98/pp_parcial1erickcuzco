<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/', 'Menu::index');
$routes->get('/eventos', 'DatosEventos::index');
$routes->get('/eventos/crear', 'DatosEventos::crear');
$routes->post('/eventos/guardar', 'DatosEventos::guardar');
$routes->get('/eventos/editar/(:num)', 'DatosEventos::editar/$1');
$routes->post('/eventos/editar/(:num)', 'DatosEventos::editar/$1');
$routes->get('/eventos/eliminar/(:num)', 'DatosEventos::eliminar/$1');
