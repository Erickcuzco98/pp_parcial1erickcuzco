<?php

namespace App\Controllers;

use App\Models\DatosEventosModel;

class DatosEventos extends BaseController
{
    public function index()
    {
        $model = new DatosEventosModel();
        $data['eventos'] = $model->findAll();
        return view('datos_eventos/index', $data);
    }

    public function crear()
    {
        return view('datos_eventos/crear');
    }

    public function guardar()
    {
        $model = new DatosEventosModel();

        $data = [
            'nombre' => $this->request->getPost('nombre'),
            'cantante_id' => $this->request->getPost('cantante_id'),
            'fecha_evento' => $this->request->getPost('fecha_evento'),
            'lugar_id' => $this->request->getPost('lugar_id'),
            'ciudad_id' => $this->request->getPost('ciudad_id'),
        ];

        if ($model->insert($data)) {
            return redirect()->to('/eventos')->with('message', 'Evento creado correctamente.');
        } else {
            return redirect()->back()->with('error', 'Error al crear el evento.');
        }
    }

    public function editar($id)
    {
        $model = new DatosEventosModel();
        $data['evento'] = $model->find($id);

        if (empty($data['evento'])) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException("No se encontró el evento con ID: $id");
        }

        if ($this->request->getMethod() === 'post') {
            $updateData = [
                'nombre' => $this->request->getPost('nombre'),
                'cantante_id' => $this->request->getPost('cantante_id'),
                'fecha_evento' => $this->request->getPost('fecha_evento'),
                'lugar_id' => $this->request->getPost('lugar_id'),
                'ciudad_id' => $this->request->getPost('ciudad_id'),
            ];

            if ($model->update($id, $updateData)) {
                return redirect()->to('/eventos')->with('message', 'Evento actualizado correctamente.');
            } else {
                return redirect()->back()->with('error', 'Error al actualizar el evento.');
            }
        }

        return view('datos_eventos/editar', $data);
    }

    public function eliminar($id)
    {
        $model = new DatosEventosModel();

        if ($model->delete($id)) {
            return redirect()->to('/eventos')->with('message', 'Evento eliminado correctamente.');
        } else {
            return redirect()->back()->with('error', 'Error al eliminar el evento.');
        }
    }
}
