<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class Menu extends Controller
{
    public function index()
    {
        return view('welcome_message');
    }
}
