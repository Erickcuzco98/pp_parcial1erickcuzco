<?php

namespace App\Models;

use CodeIgniter\Model;

class ArtistaModel extends Model
{
    protected $table      = 'artistas';
    protected $primaryKey = 'artista_id';

    protected $allowedFields = ['nombre', 'apellido', 'fecha_nacimiento', 'fecha_muerte', 'pais_id'];
}
