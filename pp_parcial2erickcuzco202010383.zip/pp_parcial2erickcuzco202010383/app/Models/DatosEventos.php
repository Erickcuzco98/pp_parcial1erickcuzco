<?php

namespace App\Controllers;

use App\Models\DatosEventosModel;
use CodeIgniter\Controller;

class DatosEventos extends Controller
{
    public function index()
    {
        $model = new DatosEventosModel();
        $data['eventos'] = $model->findAll();

        return view('datos_eventos/index', $data);
    }

    public function crear()
    {
        if ($this->request->getMethod() === 'post') {
            $model = new DatosEventosModel();
            $model->save([
                'nombre' => $this->request->getPost('nombre'),
                'cantante_id' => $this->request->getPost('cantante_id'),
                'fecha_evento' => $this->request->getPost('fecha_evento'),
                'lugar_id' => $this->request->getPost('lugar_id'),
                'ciudad_id' => $this->request->getPost('ciudad_id'),
            ]);

            return redirect()->to('/eventos');
        }

        return view('datos_eventos/crear');
    }


namespace App\Controllers;

use App\Models\EventoModel;

class DatosEventos extends BaseController
{
    public function actualizar($id)
    {
        $model = new EventoModel();

        // Datos validados que se reciben del formulario
        $data = [
            'nombre' => $this->request->getPost('nombre'),
            'cantante_id' => $this->request->getPost('cantante_id'),
            'fecha_evento' => $this->request->getPost('fecha_evento'),
            'lugar_id' => $this->request->getPost('lugar_id'),
            'ciudad_id' => $this->request->getPost('ciudad_id'),
        ];

        // Actualiza el evento en la base de datos
        if ($model->update($id, $data)) {
            // Redirigir con mensaje de éxito
            return redirect()->to(base_url('/eventos'))->with('message', 'Evento actualizado correctamente.');
        } else {
            // Manejo de errores
            return redirect()->back()->with('message', 'Error al actualizar el evento.');
        }
    }




    public function editar($id)
    {
        $model = new DatosEventosModel();
        $data['evento'] = $model->find($id);

        if ($this->request->getMethod() === 'post') {
            // Actualiza los datos
            $updateData = [
                'nombre' => $this->request->getPost('nombre'),
                'cantante_id' => $this->request->getPost('cantante_id'),
                'fecha_evento' => $this->request->getPost('fecha_evento'),
                'lugar_id' => $this->request->getPost('lugar_id'),
                'ciudad_id' => $this->request->getPost('ciudad_id'),
            ];

            // Verifica si el proceso de actualización es exitoso
            if ($model->update($id, $updateData)) {
                return redirect()->to('/eventos')->with('message', 'Evento actualizado correctamente.');
            } else {
                return redirect()->back()->with('error', 'Error al actualizar el evento.');
            }
        }

        return view('datos_eventos/editar', $data);
    }
}



   /* public function editar($id)
    {
        $model = new DatosEventosModel();
        $data['evento'] = $model->find($id);

        if ($this->request->getMethod() === 'post') {
            $model->update($id, [
                'nombre' => $this->request->getPost('nombre'),
                'cantante_id' => $this->request->getPost('cantante_id'),
                'fecha_evento' => $this->request->getPost('fecha_evento'),
                'lugar_id' => $this->request->getPost('lugar_id'),
                'ciudad_id' => $this->request->getPost('ciudad_id'),
            ]);

            return redirect()->to('/eventos');
        }

        return view('datos_eventos/editar', $data);
    }
*/
    public function eliminar($id)
    {
        $model = new DatosEventosModel();
        $model->delete($id);

        return redirect()->to('/eventos');
    }
}
