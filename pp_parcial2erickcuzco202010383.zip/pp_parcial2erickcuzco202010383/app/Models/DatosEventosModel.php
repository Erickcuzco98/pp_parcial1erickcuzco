<?php

namespace App\Models;

use CodeIgniter\Model;

class DatosEventosModel extends Model
{
    protected $table = 'datos_eventos';
    protected $primaryKey = 'evento_id';
    protected $allowedFields = ['nombre', 'cantante_id', 'fecha_evento', 'lugar_id', 'ciudad_id'];
}
