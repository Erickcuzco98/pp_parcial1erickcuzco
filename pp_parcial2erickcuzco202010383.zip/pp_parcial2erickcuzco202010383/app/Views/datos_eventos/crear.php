<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Nuevo Evento</title>
    <!-- Enlace a Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h2 class="text-center mb-4">Agregar Nuevo Evento</h2>

        <form action="<?= base_url('/eventos/guardar') ?>" method="post">
            <?= csrf_field() ?>

            <div class="mb-3">
                <label for="nombre" class="form-label">Nombre del Evento</label>
                <input type="text" class="form-control" id="nombre" name="nombre" required>
            </div>

            <div class="mb-3">
                <label for="cantante_id" class="form-label">ID del Cantante</label>
                <input type="number" class="form-control" id="cantante_id" name="cantante_id" required>
            </div>

            <div class="mb-3">
                <label for="fecha_evento" class="form-label">Fecha del Evento</label>
                <input type="date" class="form-control" id="fecha_evento" name="fecha_evento" required>
            </div>

            <div class="mb-3">
                <label for="lugar_id" class="form-label">ID del Lugar</label>
                <input type="number" class="form-control" id="lugar_id" name="lugar_id" required>
            </div>

            <div class="mb-3">
                <label for="ciudad_id" class="form-label">ID de la Ciudad</label>
                <input type="number" class="form-control" id="ciudad_id" name="ciudad_id" required>
            </div>

            <button type="submit" class="btn btn-primary">Agregar</button>
            <a href="<?= base_url('/eventos') ?>" class="btn btn-secondary">Cancelar</a>
        </form>

    <!-- Enlace a Bootstrap JS y Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.min.js"></script>
</body>
</html>
