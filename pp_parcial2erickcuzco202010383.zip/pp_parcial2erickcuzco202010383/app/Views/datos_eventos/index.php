<h2>Lista de Eventos</h2>

<?php if (session()->getFlashdata('message')): ?>
    <div class="alert alert-success">
        <?= session()->getFlashdata('message') ?>
    </div>
<?php endif; ?>

<table border="1">
    <thead>
        <tr>
            <th>ID Evento</th>
            <th>Nombre</th>
            <th>ID Cantante</th>
            <th>Fecha del Evento</th>
            <th>ID del Lugar</th>
            <th>ID de la Ciudad</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($eventos as $evento): ?>
            <tr>
                <td><?= $evento['evento_id'] ?></td>
                <td><?= $evento['nombre'] ?></td>
                <td><?= $evento['cantante_id'] ?></td>
                <td><?= $evento['fecha_evento'] ?></td>
                <td><?= $evento['lugar_id'] ?></td>
                <td><?= $evento['ciudad_id'] ?></td>
                <td>
                    <a href="<?= base_url('/eventos/editar/' . $evento['evento_id']) ?>">Editar</a>
                    <a href="<?= base_url('/eventos/eliminar/' . $evento['evento_id']) ?>" onclick="return confirm('¿Estás seguro de que deseas eliminar este evento?')">Eliminar</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<a href="<?= base_url('/eventos/crear') ?>">Agregar Nuevo Evento</a>
