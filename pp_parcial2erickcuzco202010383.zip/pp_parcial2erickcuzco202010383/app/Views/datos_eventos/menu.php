<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú Principal</title>
    <!-- Enlace a Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa; /* Color de fondo claro */
        }
        .menu-container {
            margin-top: 50px;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }
        .list-group-item {
            border-radius: 0.375rem;
        }
        .list-group-item:hover {
            background-color: #e9ecef; /* Color de fondo al pasar el ratón */
        }
    </style>
</head>
<body bgcolor="cyan">
    <div class="container menu-container">
        <h1 class="text-center mb-4">Menú Principal</h1>

        <div class="list-group">
            <a href="<?= base_url('/eventos') ?>" class="list-group-item list-group-item-action">Gestión de Eventos</a>
            <!-- Añade más enlaces aquí -->
            <!-- <a href="<?= base_url('/otra_vista') ?>" class="list-group-item list-group-item-action">Otra Vista</a> -->
        </div>
    </div>

    <!-- Enlace a Bootstrap JS y Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.min.js"></script>
</body>
</html>
